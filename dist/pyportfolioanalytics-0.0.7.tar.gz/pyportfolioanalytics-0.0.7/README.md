# Automatización del Flujo de Trabajo sobre el Proyecto Final del curso de Introducción a los Mercados Bursátiles con la librería py_portfolio_analytics en Python
#### **Realizado por Sebastian Marat Urdanegui Bisalaya**
